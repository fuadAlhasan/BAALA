package com.example.motherscaremod;


public enum UserRole
{

    MOTHER, DOCTOR

}
