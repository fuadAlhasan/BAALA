package com.example.motherscaremod;


public enum LogInPageMode
{

    LOG_IN, SIGN_UP

}
