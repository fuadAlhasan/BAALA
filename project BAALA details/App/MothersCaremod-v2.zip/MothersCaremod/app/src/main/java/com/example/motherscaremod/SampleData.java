package com.example.motherscaremod;


public class SampleData
{

    public static User[] sampleUsers = new User[] {
            new User("Ehsan", "1234", UserRole.DOCTOR),
            new User("Sabrina", "1234", UserRole.MOTHER)
    };

}
